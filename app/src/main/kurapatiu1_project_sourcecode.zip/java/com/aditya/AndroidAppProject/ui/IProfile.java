package com.aditya.AndroidAppProject.ui;

public interface IProfile {

    void onImageSelected(int resource);
}
